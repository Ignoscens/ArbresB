package imt.inged1.main;

import java.util.ArrayList;
import java.util.List;

import imt.inged1.arbreb.ArbreB;
import imt.inged1.arbreb.Noeud;

public class Main {

	public static void main(String[] args) {
		
		Noeud racine = new Noeud(2); 
		Noeud noeud1 = new Noeud(1);
		Noeud noeud3 = new Noeud(7);
		Noeud noeud4 = new Noeud(6);
		Noeud noeud5 = new Noeud(10);
		
	
		List<Noeud> liste1 = new ArrayList<>();
		liste1.add(noeud1);
		liste1.add(noeud3);
		racine.setFils(liste1);
		
		List<Noeud> liste2 = new ArrayList<>();
		liste2.add(noeud4);
		liste2.add(noeud5);
		noeud3.setFils(liste2);
		
		ArbreB arbre = new ArbreB(2,racine);
		
		arbre.search(10);
		arbre.search(7);
		arbre.search(6);
	}

}
