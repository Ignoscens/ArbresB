package imt.inged1.arbreb;

import java.util.ArrayList;
import java.util.List;

public class Noeud {
	
	private List<Integer> values = new ArrayList<>();
	
	private List<Noeud> fils = new ArrayList<>();
	
	public Noeud(Integer value) {
		super();
		this.values.add(value);
	}

	protected Noeud(Integer value, Noeud fils) {
		super();
		this.values.add(value);
		this.fils.add(fils);
	}
	
	public Noeud(Integer value, List<Noeud> fils) {
		super();
		this.values.add(value);
		this.fils=fils;
	}

	public List<Integer> getValues() {
		return values;
	}

	public void setValues(List<Integer> values) {
		this.values = values;
	}

	public List<Noeud> getFils() {
		return fils;
	}

	public void setFils(List<Noeud> fils) {
		this.fils = fils;
	}

	public boolean isFeuille() {
		return this.fils.isEmpty();
	}

	@Override
	public String toString() {
		String resultat = "Noeud [valeur=" + values;
		if (!fils.isEmpty()) {
			resultat = resultat +", fils= \n" + fils;
		}
		resultat = resultat + "]";
		return resultat;
	}
	
	

}
