package imt.inged1.arbreb;

public class ArbreB {
	
	protected static int nombresClesMaximum = 2;

	private Noeud racine;

	/**
	 * @param nombresClesMaximum
	 * nombre de cles de l'arbre B doit etre superieur ou egale a 2
	 */
	
	public ArbreB(int nombreCouplesMaximum, Noeud racine) {
		super();
		ArbreB.nombresClesMaximum = nombreCouplesMaximum;
		this.racine = racine;
	}

	public Couple search(Integer cle) {
		return search(cle, racine);
	}
	
	private Couple search(Integer cle, Noeud noeud) {
		System.out.println("Parcours du noeud : " + noeud);
		Integer indexFilsTrouve = null;
		int i = 0;
		while (i < noeud.getValues().size()) {
		
			int cleEnCours = noeud.getValues().get(i);
			if (cle == cleEnCours) {
				System.out.println("Noeud Trouv� : " + noeud + "\n");
				return new Couple(noeud, i);
			}
			if (cle < cleEnCours) {
				indexFilsTrouve = i;
				System.out.println("Index du fils Trouv� : " + indexFilsTrouve);
				break;
			}
			i ++;
		}
		if (indexFilsTrouve == null && !noeud.isFeuille()) {
			indexFilsTrouve =  noeud.getValues().size();
			System.out.println("Index du fils Trouv� : " + indexFilsTrouve);
		}
		if (noeud.isFeuille()) {
			System.out.println("Noeud Non Trouv� \n");
			return null;
		} else {
			return search(cle, noeud.getFils().get(indexFilsTrouve));
		}
	}
		
	public boolean add(Integer cle) {
		return true;
	}
	
	public boolean delete(Integer cle) {
		return true;
	}
}
