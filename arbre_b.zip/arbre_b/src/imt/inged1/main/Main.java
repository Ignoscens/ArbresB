package imt.inged1.main;

import imt.inged1.arbreb.ArbreB;

public class Main {

	public static void main(String[] args) {

		ArbreB arbre = new ArbreB(2);
		arbre.add(10);
	 System.out.println(arbre.search(10).getIndexValeur());	
	}

}
