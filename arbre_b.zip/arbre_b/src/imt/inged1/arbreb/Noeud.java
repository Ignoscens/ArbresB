package imt.inged1.arbreb;

import java.util.ArrayList;
import java.util.List;

public class Noeud {

	private Noeud parent;
	
	private List<Integer> cles = new ArrayList<>();
	
	private List<Noeud> fils = new ArrayList<>();
	
	private boolean feuille;

	protected Noeud() {
		super();
	}

	protected Noeud(Integer cle) {
		super();
		this.cles.add(cle);
	}

	protected Noeud(Noeud parent, Integer cle, Noeud fils) {
		super();
		this.parent = parent;
		this.cles.add(cle);
		this.fils.add(fils);
	}

	protected Noeud(Noeud parent) {
		super();
		this.parent = parent;
	}

	protected Noeud getParent() {
		return parent;
	}

	protected void setParent(Noeud parent) {
		this.parent = parent;
	}

	public List<Integer> getCles() {
		return cles;
	}

	public void setCles(List<Integer> cles) {
		this.cles = cles;
	}

	public List<Noeud> getFils() {
		return fils;
	}

	public void setFils(List<Noeud> fils) {
		this.fils = fils;
	}

	public boolean isFeuille() {
		return feuille;
	}

	public void setFeuille(boolean feuille) {
		this.feuille = feuille;
	}

}
