package imt.inged1.arbreb;

public class Couple {

	private Noeud noeud;
	
	private Integer indexValeur;
	
	public Couple(Noeud noeud, Integer indexValeur) {
		super();
		this.noeud = noeud;
		this.indexValeur = indexValeur;
	}

	public Noeud getNoeud() {
		return noeud;
	}

	public void setNoeud(Noeud noeud) {
		this.noeud = noeud;
	}

	public Integer getIndexValeur() {
		return indexValeur;
	}

	public void setIndexValeur(Integer indexValeur) {
		this.indexValeur = indexValeur;
	}
}
