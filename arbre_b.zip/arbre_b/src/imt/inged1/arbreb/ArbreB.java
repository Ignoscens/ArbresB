package imt.inged1.arbreb;

public class ArbreB {
	
	protected static int nombresClesMaximum = 2;

	private Noeud racine;

	/**
	 * @param nombresClesMaximum
	 * nombre de cles de l'arbre B doit etre superieur ou egale a 2
	 */
	public ArbreB(int nombreCouplesMaximum) {
		super();
		ArbreB.nombresClesMaximum = nombreCouplesMaximum;
		this.racine = new Noeud(0);
	}

	protected Noeud getRacine() {
		return racine;
	}

	protected void setRacine(Noeud racine) {
		this.racine = racine;
	}

	public Couple search(Integer cle) {
		return search(cle, racine);
	}
	
	private Couple search(Integer cle, Noeud noeud) {
		Integer indexFilsTrouve = null;
		int i = 0;
		while (indexFilsTrouve != null && i < noeud.getCles().size()) {
			int cleEnCours = noeud.getCles().get(i);
			if (cle == cleEnCours) {
				return new Couple(noeud, i);
			}
			if (cle < cleEnCours) {
				indexFilsTrouve = i;
			}
			i ++;
		}
		if (indexFilsTrouve == null) {
			indexFilsTrouve =  noeud.getCles().size();
		}
		if (noeud.isFeuille()) {
			return null;
		} else {
			return search(cle, noeud.getFils().get(indexFilsTrouve));
		}
	}
		
	public boolean add(Integer cle) {
		return true;
	}
	
	public boolean delete(Integer cle) {
		return true;
	}
}
